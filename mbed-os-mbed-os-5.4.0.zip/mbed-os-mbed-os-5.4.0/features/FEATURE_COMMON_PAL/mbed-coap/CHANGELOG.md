# Change Log

## [v4.0.0](https://github.com/ARMmbed/mbed-coap/releases/tag/v4.0.2)

**New feature**

 - Initial release of mbed-coap separated from mbed-client-c
